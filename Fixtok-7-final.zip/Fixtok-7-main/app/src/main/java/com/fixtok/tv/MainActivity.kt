package com.fixtok.tv

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.fixtok.tv.databinding.ActivityMainBinding
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TIKTOK_URL =
            "https://www.tiktok.com/"

        private const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/131.0.0.0 Safari/537.36"

        private const val MOUSE_SPEED = 16f

        // WebView initial scale
        private const val DESKTOP_SCALE = 90

        // Real page scale.
        // 0.90 = 90%
        private const val TV_SCALE = 0.90f

        // Audio
        private const val BASS_STRENGTH = 1000
        private const val AUDIO_GAIN_MB = 0

        // Connection retry
        private const val MAX_RETRIES = 5
        private const val BASE_RETRY_DELAY_MS = 2000L

        // Double-back-to-exit window
        private const val EXIT_CONFIRM_WINDOW_MS = 2000L
    }

    private lateinit var binding: ActivityMainBinding

    private var splashHidden = false

    private var mouseX = 0f
    private var mouseY = 0f

    private var tvAudio: TvAudioController? = null

    private var lastAppliedPageZoom = 1f

    private val mainHandler = Handler(Looper.getMainLooper())

    private var retryCount = 0
    private var pendingRetry = false

    private var popupWebView: WebView? = null

    private var lastBackPressTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding =
            ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        enterFullscreen()

        // Android TV audio effects
        tvAudio = TvAudioController()

        tvAudio?.enable()

        tvAudio?.setBass(
            BASS_STRENGTH
        )

        tvAudio?.setGain(
            AUDIO_GAIN_MB
        )

        setupWebView()
        setupMouse()
        animateSplashIn()

        if (savedInstanceState == null) {

            binding.webView.loadUrl(
                TIKTOK_URL
            )

        } else {

            binding.webView.restoreState(
                savedInstanceState
            )
        }

        binding.root.post {
            centerMouse()
        }
    }

    private fun enterFullscreen() {

        window.statusBarColor =
            Color.BLACK

        window.navigationBarColor =
            Color.BLACK

        if (
            android.os.Build.VERSION.SDK_INT >=
            android.os.Build.VERSION_CODES.R
        ) {

            window.setDecorFitsSystemWindows(
                false
            )

            window.insetsController?.let { controller ->

                controller.hide(
                    WindowInsets.Type.systemBars()
                )

                controller.systemBarsBehavior =
                    WindowInsetsController
                        .BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }

        } else {

            @Suppress("DEPRECATION")

            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {

        val webView =
            binding.webView

        webView.setLayerType(
            View.LAYER_TYPE_HARDWARE,
            null
        )

        webView.isFocusable = true

        webView.isFocusableInTouchMode = true

        webView.settings.apply {

            javaScriptEnabled = true

            domStorageEnabled = true

            databaseEnabled = true

            javaScriptCanOpenWindowsAutomatically =
                true

            // Needed so window.open() popups (Google/Facebook/Apple OAuth
            // login flows used by TikTok) actually open instead of being
            // silently dropped. Handled in onCreateWindow below.
            setSupportMultipleWindows(
                true
            )

            mediaPlaybackRequiresUserGesture =
                false

            allowFileAccess = false

            allowContentAccess = false

            cacheMode =
                WebSettings.LOAD_DEFAULT

            useWideViewPort = true

            // Native WebView page zoom. Do NOT use CSS zoom or View.scaleX/scaleY:
            // TikTok relies heavily on fixed/absolute layout and those can break it.
            loadWithOverviewMode = false

            setSupportZoom(true)

            builtInZoomControls = true

            displayZoomControls = false

            textZoom = 100

            defaultFontSize = 16

            defaultFixedFontSize = 16

            userAgentString =
                DESKTOP_USER_AGENT
        }

        // Initial WebView scale.
        webView.setInitialScale(
            DESKTOP_SCALE
        )

        CookieManager.getInstance().apply {

            setAcceptCookie(true)

            setAcceptThirdPartyCookies(
                webView,
                true
            )
        }

        webView.webViewClient =
            object : WebViewClient() {

                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    return false
                }

                override fun onPageStarted(
                    view: WebView,
                    url: String,
                    favicon: android.graphics.Bitmap?
                ) {
                    super.onPageStarted(view, url, favicon)
                    lastAppliedPageZoom = 1f
                }

                override fun onScaleChanged(
                    view: WebView,
                    oldScale: Float,
                    newScale: Float
                ) {
                    super.onScaleChanged(view, oldScale, newScale)
                    lastAppliedPageZoom = newScale
                }

                override fun onPageFinished(
                    view: WebView,
                    url: String
                ) {
                    super.onPageFinished(
                        view,
                        url
                    )

                    // A page actually finished loading: whatever connection
                    // problem we may have been retrying is resolved.
                    retryCount = 0
                    pendingRetry = false
                    hideErrorOverlay()

                    // Safe in-page bass: only attaches to media elements when
                    // Web Audio is allowed for that media (same-origin/CORS).
                    // It never touches a cross-origin element that could become muted.
                    injectSafeWebAudioBass(view)

                    // setInitialScale is only a starting hint. The actual
                    // page zoom is applied once, using the current scale,
                    // so 0.90 is absolute instead of multiplying 0.90 again
                    // and again on repeated page callbacks.
                    view.postDelayed({
                        applyTvZoom(view)
                    }, 350)

                    // Hide the splash once the main document has actually
                    // finished loading, regardless of the exact final host:
                    // a region-blocked page or CDN redirect should still
                    // reveal the WebView instead of leaving the splash
                    // stuck on screen forever.
                    if (!splashHidden) {
                        hideSplash()
                    }
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: android.webkit.WebResourceError
                ) {
                    super.onReceivedError(
                        view,
                        request,
                        error
                    )

                    if (
                        request.isForMainFrame
                    ) {
                        scheduleRetry(view)
                    }
                }
            }

        webView.webChromeClient =
            object : WebChromeClient() {

                private var customView:
                    View? = null

                private var customViewCallback:
                    CustomViewCallback? = null

                override fun onShowCustomView(
                    view: View,
                    callback: CustomViewCallback
                ) {

                    customView = view

                    customViewCallback =
                        callback

                    binding.fullscreenContainer
                        .addView(
                            view,
                            FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT
                            )
                        )

                    binding.fullscreenContainer
                        .visibility =
                        View.VISIBLE
                }

                override fun onHideCustomView() {

                    customView?.let {

                        binding.fullscreenContainer
                            .removeView(it)
                    }

                    customView = null

                    customViewCallback
                        ?.onCustomViewHidden()

                    customViewCallback = null

                    binding.fullscreenContainer
                        .visibility =
                        View.GONE
                }

                override fun onCreateWindow(
                    view: WebView,
                    isDialog: Boolean,
                    isUserGesture: Boolean,
                    resultMsg: Message
                ): Boolean {

                    // TikTok's "Continue with Google/Facebook/Apple" login
                    // opens via window.open(). Without handling this, the
                    // popup silently never appears and login is impossible.
                    closePopup()

                    val popup = WebView(this@MainActivity).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.userAgentString = DESKTOP_USER_AGENT

                        webViewClient = object : WebViewClient() {

                            override fun shouldOverrideUrlLoading(
                                v: WebView,
                                req: WebResourceRequest
                            ): Boolean {
                                // Let the OAuth flow navigate freely inside
                                // the popup itself.
                                return false
                            }

                            override fun onPageFinished(
                                v: WebView,
                                url: String
                            ) {
                                super.onPageFinished(v, url)

                                // Once the flow lands back on TikTok, the
                                // login is done: close the popup and reflect
                                // the result in the main WebView.
                                val host = runCatching { android.net.Uri.parse(url).host?.lowercase() }.getOrNull()
                                if (host == "tiktok.com" || host?.endsWith(".tiktok.com") == true) {
                                    closePopup()
                                    binding.webView.loadUrl(url)
                                }
                            }
                        }
                    }

                    popupWebView = popup

                    binding.popupContainer.removeAllViews()
                    binding.popupContainer.addView(
                        popup,
                        FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT
                        )
                    )
                    binding.popupContainer.visibility = View.VISIBLE
                    popup.requestFocus()

                    val transport =
                        resultMsg.obj as WebView.WebViewTransport
                    transport.webView = popup
                    resultMsg.sendToTarget()

                    return true
                }

                override fun onCloseWindow(window: WebView) {
                    closePopup()
                }

                override fun onPermissionRequest(
                    request: PermissionRequest
                ) {
                    // This app does not request Android camera/microphone permissions.
                    // Deny web-origin requests rather than implicitly granting them.
                    runOnUiThread {
                        runCatching { request.deny() }
                    }
                }
            }

        webView.requestFocus()
    }

    private fun closePopup() {
        popupWebView?.let { popup ->
            binding.popupContainer.removeView(popup)
            popup.destroy()
        }
        popupWebView = null
        binding.popupContainer.visibility = View.GONE
    }

    private fun scheduleRetry(view: WebView) {

        if (pendingRetry) {
            return
        }

        if (retryCount >= MAX_RETRIES) {
            showErrorOverlay(
                getString(R.string.error_no_connection_final)
            )
            return
        }

        showErrorOverlay(
            getString(R.string.error_no_connection)
        )

        pendingRetry = true

        val delay =
            BASE_RETRY_DELAY_MS *
                2.0.pow(retryCount).toLong()

        retryCount++

        mainHandler.postDelayed({
            pendingRetry = false
            view.loadUrl(TIKTOK_URL)
        }, delay)
    }

    private fun showErrorOverlay(message: String) {
        binding.errorText.text = message
        binding.errorContainer.visibility = View.VISIBLE
    }

    private fun hideErrorOverlay() {
        binding.errorContainer.visibility = View.GONE
    }

    private fun applyTvZoom(webView: WebView) {
        // Use WebView's page zoom, not View.scaleX/scaleY or CSS zoom.
        // setInitialScale() is the primary mechanism; zoomBy() is only used
        // as a fallback when Android did not apply the initial scale.
        val target = TV_SCALE
        val current = webView.scale
        Log.d("FixTokZoom", "before: webView.scale=$current target=$target")

        try {
            webView.settings.setSupportZoom(true)
            webView.settings.builtInZoomControls = true
            webView.settings.displayZoomControls = false
            webView.settings.loadWithOverviewMode = false
            webView.settings.useWideViewPort = true

            // Re-apply the requested initial page scale. This must happen
            // before/around the first layout of the document.
            webView.setInitialScale(DESKTOP_SCALE)

            webView.postDelayed({
                val afterInitial = webView.scale
                Log.d("FixTokZoom", "after initialScale: webView.scale=$afterInitial")

                // On WebView versions where setInitialScale is ignored by
                // the page viewport, make one relative zoom adjustment.
                if (afterInitial > 0.01f && kotlin.math.abs(afterInitial - target) > 0.02f) {
                    val factor = target / afterInitial
                    if (factor in 0.5f..2.0f && kotlin.math.abs(factor - 1f) > 0.01f) {
                        webView.zoomBy(factor)
                        Log.d("FixTokZoom", "fallback zoomBy factor=$factor")
                    }
                }
            }, 250)
        } catch (t: Throwable) {
            Log.e("FixTokZoom", "Unable to apply WebView page zoom", t)
        }
    }

    private fun injectSafeWebAudioBass(webView: WebView) {
        val js = """
            (() => {
              if (window.__fixtokBassInstalled) return;
              window.__fixtokBassInstalled = true;

              const BASS_DB = 8;
              const contexts = new Map();

              function sameOrigin(src) {
                try { return new URL(src, location.href).origin === location.origin; }
                catch (_) { return false; }
              }

              function attach(el) {
                if (!el || contexts.has(el) || !el.currentSrc) return;

                // Do NOT connect media that has no CORS permission.
                // MediaElementSource would otherwise silence cross-origin audio.
                const corsOK = el.crossOrigin === 'anonymous' ||
                               el.crossOrigin === 'use-credentials' ||
                               sameOrigin(el.currentSrc);
                if (!corsOK) return;

                try {
                  const Ctx = window.AudioContext || window.webkitAudioContext;
                  if (!Ctx) return;
                  const ctx = new Ctx();
                  const source = ctx.createMediaElementSource(el);
                  const bass = ctx.createBiquadFilter();
                  bass.type = 'lowshelf';
                  bass.frequency.value = 140;
                  bass.gain.value = BASS_DB;
                  source.connect(bass);
                  bass.connect(ctx.destination);
                  contexts.set(el, {ctx, bass});
                  const resume = () => { try { ctx.resume(); } catch (_) {} };
                  el.addEventListener('play', resume, {passive:true});
                  resume();
                } catch (_) {
                  // Never interfere with normal playback if Web Audio is rejected.
                }
              }

              function scan() {
                document.querySelectorAll('video,audio').forEach(attach);
              }

              scan();
              new MutationObserver(scan).observe(document.documentElement, {childList:true, subtree:true});
              setInterval(scan, 5000);
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun setupMouse() {

        binding.mouseCursor.apply {

            isClickable = false

            isFocusable = false

            isFocusableInTouchMode = false

            setOnTouchListener { _, _ ->
                false
            }
        }
    }

    private fun centerMouse() {

        val width =
            binding.root.width.toFloat()

        val height =
            binding.root.height.toFloat()

        if (
            width <= 0f ||
            height <= 0f
        ) {
            return
        }

        mouseX =
            width / 2f

        mouseY =
            height / 2f

        updateMousePosition()
    }

    private fun moveMouse(
        dx: Float,
        dy: Float
    ) {

        val width =
            binding.root.width.toFloat()

        val height =
            binding.root.height.toFloat()

        if (
            width <= 0f ||
            height <= 0f
        ) {
            return
        }

        mouseX = min(
            width -
                binding.mouseCursor.width,
            max(
                0f,
                mouseX + dx
            )
        )

        mouseY = min(
            height -
                binding.mouseCursor.height,
            max(
                0f,
                mouseY + dy
            )
        )

        updateMousePosition()
    }

    private fun updateMousePosition() {

        binding.mouseCursor.translationX =
            mouseX

        binding.mouseCursor.translationY =
            mouseY
    }

    private fun clickMouse() {

        val webView =
            binding.webView

        val cursorCenterX =
            mouseX +
                binding.mouseCursor.width / 2f

        val cursorCenterY =
            mouseY +
                binding.mouseCursor.height / 2f

        val x =
            cursorCenterX.coerceIn(
                0f,
                webView.width.toFloat()
            )

        val y =
            cursorCenterY.coerceIn(
                0f,
                webView.height.toFloat()
            )

        val downTime =
            SystemClock.uptimeMillis()

        val downEvent =
            MotionEvent.obtain(
                downTime,
                downTime,
                MotionEvent.ACTION_DOWN,
                x,
                y,
                0
            )

        webView.dispatchTouchEvent(
            downEvent
        )

        downEvent.recycle()

        val upTime =
            SystemClock.uptimeMillis()

        val upEvent =
            MotionEvent.obtain(
                downTime,
                upTime,
                MotionEvent.ACTION_UP,
                x,
                y,
                0
            )

        webView.dispatchTouchEvent(
            upEvent
        )

        upEvent.recycle()
    }

    override fun dispatchKeyEvent(
        event: KeyEvent
    ): Boolean {

        if (
            event.action ==
            KeyEvent.ACTION_DOWN
        ) {

            when (event.keyCode) {

                KeyEvent.KEYCODE_DPAD_UP -> {

                    moveMouse(
                        0f,
                        -MOUSE_SPEED
                    )

                    return true
                }

                KeyEvent.KEYCODE_DPAD_DOWN -> {

                    moveMouse(
                        0f,
                        MOUSE_SPEED
                    )

                    return true
                }

                KeyEvent.KEYCODE_DPAD_LEFT -> {

                    moveMouse(
                        -MOUSE_SPEED,
                        0f
                    )

                    return true
                }

                KeyEvent.KEYCODE_DPAD_RIGHT -> {

                    moveMouse(
                        MOUSE_SPEED,
                        0f
                    )

                    return true
                }

                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> {

                    if (
                        event.repeatCount == 0
                    ) {
                        clickMouse()
                    }

                    return true
                }

                KeyEvent.KEYCODE_BACK -> {

                    if (popupWebView != null) {

                        closePopup()

                    } else if (
                        binding.webView.canGoBack()
                    ) {

                        binding.webView.goBack()

                    } else {

                        val now =
                            SystemClock.elapsedRealtime()

                        if (
                            now - lastBackPressTime <=
                            EXIT_CONFIRM_WINDOW_MS
                        ) {

                            finish()

                        } else {

                            lastBackPressTime = now

                            Toast.makeText(
                                this,
                                R.string.press_back_again_to_exit,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    return true
                }
            }
        }

        return super.dispatchKeyEvent(
            event
        )
    }

    private fun animateSplashIn() {

        binding.splashLogo.apply {

            alpha = 0f

            scaleX = 0.8f

            scaleY = 0.8f

            animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(700L)
                .start()
        }

        binding.splashTitle.apply {

            alpha = 0f

            animate()
                .alpha(1f)
                .setStartDelay(300L)
                .setDuration(500L)
                .start()
        }

        binding.splashByManas.apply {

            alpha = 0f

            animate()
                .alpha(1f)
                .setStartDelay(500L)
                .setDuration(500L)
                .start()
        }
    }

    private fun hideSplash() {

        if (splashHidden) {
            return
        }

        splashHidden = true

        binding.splashContainer
            .animate()
            .alpha(0f)
            .setDuration(500L)
            .withEndAction {

                binding.splashContainer
                    .visibility =
                    View.GONE
            }
            .start()
    }

    override fun onSaveInstanceState(
        outState: Bundle
    ) {

        binding.webView.saveState(
            outState
        )

        super.onSaveInstanceState(
            outState
        )
    }

    override fun onResume() {
        super.onResume()

        binding.webView.onResume()

        binding.webView.resumeTimers()

        tvAudio?.enable()

        tvAudio?.setBass(
            BASS_STRENGTH
        )

        tvAudio?.setGain(
            AUDIO_GAIN_MB
        )
    }

    override fun onPause() {

        binding.webView.onPause()

        binding.webView.pauseTimers()

        tvAudio?.disable()

        super.onPause()
    }

    override fun onDestroy() {

        mainHandler.removeCallbacksAndMessages(null)

        closePopup()

        tvAudio?.release()

        tvAudio = null

        binding.webView.stopLoading()

        binding.webView.removeAllViews()

        binding.webView.destroy()

        super.onDestroy()
    }
}
